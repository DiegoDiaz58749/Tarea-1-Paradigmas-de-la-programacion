class administrador: Public Usuario{

  public: 
    string asignar_turnos_();
    string agregar_usuario();
    string eliminar_usuario();
}
