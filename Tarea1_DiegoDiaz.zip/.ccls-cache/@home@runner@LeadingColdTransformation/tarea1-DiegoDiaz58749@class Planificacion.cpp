class planificacion: public Turno, public Usuario{
  public:
   string Dia;
   string Atraso;
   string Estado;
   string RetiroAnticipado;
   TiempoPlanificacion();
}
