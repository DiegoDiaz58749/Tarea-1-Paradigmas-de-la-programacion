class TurnoDia: Public Turno{
  public:
    string MinutosAtrasosPermitidos;
    TotalMenosHorasAtraso();