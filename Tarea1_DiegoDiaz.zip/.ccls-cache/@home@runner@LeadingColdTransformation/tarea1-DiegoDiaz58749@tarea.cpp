#include<iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <sstream>

using namespace std;

class Usuario{
 public:
   string Identificador;
   string Nombre;
   string Marcas;
   string planificacion;
   Marcar();
   Informe();
usuario();
usuraio(string identificador,string Nombre,string Marcas, string planificacion);
}

class administrador{

  public: 
    string asignar_turnos_();
    string agregar_usuario();
    string eliminar_usuario();
}

class planificacion{
  public:
   string Dia;
   string Estado;
   string RetiroAnticipado;
   TiempoPlanificacion();
}

class Marca{
  public:
    string Marca;
    string Hora;
    string Tipo;
}

class Turno{
  public:
    string IdTurno;
    string HoraInicio;
    string HoraFin;
    TotalHoras();
}

class TurnoDia{
  public:
    string MinutosAtrasosPermitidos;
    TotalMenosHorasAtraso();

}

class TurnoTarde{
  public:
   string MinutosRetiroAnticipado;
   TotalHorasMenosAnticipo();
}