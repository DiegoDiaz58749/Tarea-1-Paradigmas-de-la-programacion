class Marca: public Usuario{
  public:
    string Marca;
    string Hora;
    string Tipo;
}
