class TurnoTarde: Public Turno{
  public:
   string MinutosRetiroAnticipado;
   TotalHorasMenosAnticipo();
}