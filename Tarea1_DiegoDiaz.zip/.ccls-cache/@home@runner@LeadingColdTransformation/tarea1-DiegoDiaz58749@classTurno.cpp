class Turno: public Administrador{
  public:
    string IdTurno;
    string HoraInicio;
    string HoraFin;
    TotalHoras();
}