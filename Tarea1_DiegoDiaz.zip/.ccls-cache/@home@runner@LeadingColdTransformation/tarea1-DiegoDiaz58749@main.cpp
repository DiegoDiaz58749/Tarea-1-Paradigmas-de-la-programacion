#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <stdio.h>

using namespace std;

//Dada una cadena de caracteres, devuelve un vector de strings
//separada por el caracter indicado en delimiter
vector<string> split(string str, char delimiter) {
    vector<string> internal;
    stringstream ss(str); // Turn the string into a stream.
    string tok;

    while(getline(ss, tok, delimiter)) {        
        internal.push_back(tok);
    }
    
    return internal;
}

int main() {
    
    //Lee el archivo y lo guarda en un vector
    vector<string> lines;// lo guarda en el vector lines
  
    string line;
    ifstream myfile ("entrada/Marcas.txt");
    if (myfile.is_open())
    {
        while ( getline (myfile,line) )
        {
            lines.push_back(line);
        }
        myfile.close();
    }
    
    string id = "";
    //Impresion de los elementos del vector utilizando split separados por ";"
    for (int i = 0; i < lines.size(); i++) {
        vector<string> splitted = split(lines[i], ';');
        
        for (int j = 0; j < splitted.size(); j++) {
            //Por un error visual puede no imprimir el primer caracter
            //pero al guardarlo en una variable el valor esta completo           
            cout << splitted[j] << " ";
        }        
        cout << endl;
    }
    return 0;
}

// Funcion para contar los minutos
int HoraTotal(vector<string> Hora,string HoraInicio,string HoraFin, string Minutos){
  
  int MinutosInicio;
  int MinutosPermitidos;
  int MinutosFin;
  int TotalMinutos;
  int HorasDeInicio;
  int HoraFin;
  
  
  Hora.push_back(HoraInicio);
  Hora.push_back(HoraFin);
  vector<string>Hora_;
  
  for(int i = 0; i < Hora.size(); i++) {
    vector<string> splitted = split(Hora[i], ':');
    for (int j = 0; j < splitted.size(); j++) {
    Hora.push_back(splitted[j]);
    }
  }
  
  MinutosPermitidos = stoi(Minutos);
  HorasDeInicio = stoi(Hora[0]);
  MinutosInicio = stoi(Hora[1]);
  HoraFin = stoi(Hora[2]);
  MinutosFin = stoi(Hora[3]);
  
  TotalMinutos = ((HoraFin*60)-(HorasDeInicio*60))+(MinutosFin-MinutosInicio);
// Total de minutos trabajados 
  TotalMinutos=TotalMinutos -MinutosPermitidos;
 // retorno los minutos totales
  return TotalMinutos;
  };
// Constructor de archivo
void CrearArchivo(string User,vector<string> text){
  string txt =".txt";
  string IdArchivo;
  IdArchivo=User+text; // crear identificador del archivo
  freopen(IdArchivo.c_str(),"w",stdout);
  for(int i=0;i<text.size();i++){
    cout<<text[i]<<endl;
  }
  fclose(stdout);
};

int main(){
// Vector
  vector<Usuarios> Usuarios;
  vector<Turno> Turnos;
  vector<Planificador> Planificador;
  vector<marca> Marcas;
 //Usuario
  vector<string> ArchivoUsuario;
  string linea_user;
  ifstream myuser ("user.txt");
  if (myuser.is_open()){
    while ( getline (myuser,linea_user) ){
      user_arch.push_back(linea_user);
    };
    myuser.close();
  };u
  
  string IdUsuario;
  string Nombre;
  Usuario;
  
  for (int i = 0; i < ArchivoUsuario.size(); i++) {
    vector<string> splitted = split(ArchivoUsuario[i], ';');
    for (int j = 0; j < splitted.size(); j=j+2) {
      IdUsuario=splitted[j];
      Nombre=splitted[j+1];
      User.IdUsuario=IdUsuario;
      User.NombreUsuario=nombre;
      Usuarios.push_back(User);
    }; 
  };
  cout<< Usuarios.size()<<endl;
  for(int i=0 ; i< Usuarios.size();i++ ){
    usuario_us Test;
    Test = usuarios[i];
    cout << Test.IdUsuario + ";" + Test.NombreUsuario <<endl; 
  };
  // Lectura Archivo Turno
  vector<string> ArchivoTurno;
  string LineaTurno;
  ifstream myturno ("turnos.txt");
  if (myturno.is_open()){
    while ( getline (myturno,linea_turno) ){
      turno_arch.push_back(linea_turno);
      };
    myturno.close();
  };
  
  string IdTurno;
  string HoraInicio;
  string HoraFin;
  string MinutosPermitidos;
  string Turnos_np;
  turno TurnoUsuario;
  
  for (int i = 0; i < ArchivoTurno.size(); i++) {
    vector<string> splitted = split(ArchivoTurno[i], ';');
    for (int j = 0; j < splitted.size(); j=j+5) {
      IdTurno = splitted[j];
      HoraInicio = splitted[j+1];
      HoraFin=splitted[j+2];
      MinutosPermitidos=splitted[j+3];
      TurnoUsuario=splitted[j+4];
      TurnoUsuario.id_turno=id_turno;
      TurnoUsuario.HoraInicio=HoraInicio;
      TurnoUsuario.HoraFin = HoraFin;
      TurnoUsuario.MinutosPermitidos = MinutosPermitidos;
      TurnoUsuario.TurnoUsuario=TurnoUsuario;
      Turnos.push_back(TurnoUsuario);
      }; 
  };
  cout<< Turnos.size()<<endl;
  for(int i=0 ; i< Turnos.size();i++ ){
    turno Test;
    Test = Turnos[i];
    cout << Test.IdTurno + "-" + Test.HoraInicio + "-"+ Test.HoraFin + "-" + Test.MinutosPermitidos + "--"+Test.Turnos_np <<endl; 
  };
 
 //Planificacion
  vector<string> ArchivoPlanificacion;
  string Planicacion_Linea;
  ifstream myplani ("planificacion.txt");
  if (myplani.is_open()){
    while ( getline (myplani,Planicacion_Linea) ){
      ArchivoPlanificacion.push_back(Planicacion_Linea);
      };
    myplani.close();
  };
  
  string IdTurnoPlanificacion;
  string DiaPlanificacion;
  string Estado;
  string Atraso;
  string RetiroAnticipado;
  string IdUsuarioPlanificacion;
  planif PlanificacionUsuario;
  
  for (int i = 0; i < ArchivoPlanificacion.size(); i++) {
    vector<string> splitted = split(ArchivoPlanificacion[i], ';');
    for (int j = 0; j < splitted.size(); j=j+6) {
      IdTurnoPlanificacion=splitted[j];
      DiaPlanificacion=splitted[j+1];
      Estado=splitted[j+2];
      Atraso=splitted[j+3];
      RetiroAnticipado=splitted[j+4];
      IdUsuarioPlanificacion=splitted[j+5];
      PlanificacionUsuario.IdTurnoPlanificacion=IdTurnoPlanificacion;
      PlanificacionUsuario.DiaPlanificacion=DiaPlanificacion;
      PlanificacionUsuario.Estado=Estado;
      PlanificacionUsuario.Atraso=Atraso;
      PlanificacionUsuario.RetiroAnticipado=RetiroAnticipado;
      PlanificacionUsuario.IdUsuarioPlanificacion=IdUsuarioPlanificacion;
      Planificador.push_back(PlanificacionUsuario);
    }; 
  };
  cout<< Planificador.size()<<endl;
  for(int i=0 ; i< Planificador.size();i++ ){
    planif Test;
    Test = Planificador[i];
    cout << Test.IdTurno+"~~"+Test.DiaPlanificacion+"~~"+Test.Estado+"~~"+Test.Atraso+"~~"+Test.RetiroAnticipado+"~~"+ Test.IdUsuario << endl;
  };
 
//Archivo Marcas
  vector<string> ArchivoMarcas;
  string linea_marca;
  ifstream mymarca ("marcas.txt");
  if (mymarca.is_open()){
    while ( getline (mymarca,linea_marca) ){
      marcas_arch.push_back(linea_marca);
      };
    mymarca.close();
  };
  
  string IdUsuarioMarcas;
  string Dia;
  string Hora;
  string Tipo;
  marca MarcaUsuario;
  
  for (int i = 0; i < ArchivoMarcas.size(); i++) {
    vector<string> splitted = split(ArchivoMarcas[i], ';');
    for (int j = 0; j < splitted.size(); j=j+4) {
      IdUsuarioMarca=splitted[j];
      Dia=splitted[j+1];
      Hora=splitted[j+2];
      Tipo=splitted[j+3];
      MarcaUsuario.IdUsuario=IdUsuarioMarcas;
      MarcaUsuario.Dia=Dia;
      MarcaUsuario.Hora=Hora;
      MarcaUsuario.Tipo=Tipo;
      marcas.push_back(MarcaUsuario);
      }; 
  };
  cout<< Marcas.size()<<endl;
  for(int i=0 ; i< marcas.size();i++ ){
    marca Test;
    Test = marcas[i];
    cout << Test.IdUsuario + "/-/" + Test.Dia + "/-/"+ Test.Hora + "/-/" + Test.Tipo<<endl; 
  };
  cout<<"///////////////////////////////////////////////"<<endl;
////////////////////////////////////////////////////////////////
  
  return 0;
};