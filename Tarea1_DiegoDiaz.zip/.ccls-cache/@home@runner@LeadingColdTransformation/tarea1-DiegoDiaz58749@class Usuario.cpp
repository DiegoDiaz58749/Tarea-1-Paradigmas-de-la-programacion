class Usuario: public Planificador, public Administrador{
 public:
   string Identificador;
   string Nombre;
   string Marcas;
   string planificacion;
   Marcar();
   Informe();
usuario();
usuraio(string identificador,string Nombre,string Marcas, string planificacion);
}