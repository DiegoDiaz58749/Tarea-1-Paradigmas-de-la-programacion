# Tarea1
Este repositorio contiene el código base para la tarea uno, el cual trae un archivo main
con ejemplos de lectura

Existe un archivo .gitignore que por ahora ignora los archivos main y aquellos con la extensión `.exe` en el repositorio.


Para ejecutar su programa, utilice el siguiente comando:
```
g++ main.cpp -o main
```

En caso de agregar nuevas clases y archivo su solución, debe ir 
añadiendo los archivos a la linea de compilación.


```
g++ main.cpp clase_1.cpp clase_2.cpp -o main
```